# List of Breaking Changes for 4.x

-   Icon bell-full.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon info-panel-closed.svg is deprecated as of v3.136.0 use info-circle instead
-   Icon info-panel-open.svg is deprecated as of v3.136.0 use info-circle-open instead
-   Icon environment.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon environment-connected.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon environment-disconnected .svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon share-alt.svg is deprecated as of v3.136.0 use share.svg instead
-   Icon third-party.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon send.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon devices.svg is deprecated as of v3.136.0 use mobile-devices instead
-   Icon pin-full.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon megaphone-full.svg is deprecated as of v3.136.0 and will be removed with no replacement
-   Icon social-twitter.svg is deprecated as of v3.136.0 and will be removed with no replacement
